﻿using System.Web.Mvc;
using MvcContrib.PortableAreas;

namespace $safeprojectname$
{
    public class $safeprojectname$Registration : MvcContrib.PortableAreas.PortableAreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "$safeprojectname$";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context, IApplicationBus bus)
        {
            context.MapRoute("$safeprojectname$_ResourceRoute", "$safeprojectname$/resource/{resourceName}",
               new { controller = "EmbeddedResource", action = "Index" },
               new string[] { "MvcContrib.PortableAreas" });

            context.MapRoute("$safeprojectname$_ResourceImageRoute", "$safeprojectname$/images/{resourceName}",
              new { controller = "EmbeddedResource", action = "Index", resourcePath = "images" },
              new string[] { "MvcContrib.PortableAreas" });

            context.MapRoute(
                "$safeprojectname$_default",
                "$safeprojectname$/{controller}/{action}/{id}",
                new { action = "Index", controller = "Home", id = UrlParameter.Optional }
            );

            this.RegisterAreaEmbeddedResources();
        }

    }
}
